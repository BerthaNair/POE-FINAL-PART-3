
// 360 BOYZ SECURE: Contact + Enquiry Forms 
// This is for the Administrators email

const adminEmail = "ST10510907@rcconnect.edu.za";

const namePattern = /^[A-Za-zÀ-ÖØ-öø-ÿ][A-Za-zÀ-ÖØ-öø-ÿ\s'-]*$/;
const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

//VALIDATION FUNCTIONS
function isValidName(name) {
    return namePattern.test(name);
}

function isValidEmail(email) {
    return emailPattern.test(email);
}

function isValidPhone(phone) {
    const cleanPhone = String(phone).replace(/[\s()-]/g, "");

    // Must contain exactly 10 digits, or +27 followed by 9 digits
    const phonePattern = /^(?:0[6-8][0-9]{8}|\+27[6-8][0-9]{8})$/;
    // Return true only if the entire number matches
    return phonePattern.test(cleanPhone);
}

//SEND email
async function sendToAdmin(data) {
    const response = await fetch(
        "https://formsubmit.co/ajax/" + encodeURIComponent(adminEmail),
        {
            method: "POST",

            headers: {
                "Content-Type": "application/json",
                "Accept": "application/json"
            },

            body: JSON.stringify({
                ...data,
                _template: "table"
            })
        }
    );

    const result = await response.json();

    if (
        !response.ok ||
        !(result.success === true || result.success === "true")
    ) {
        throw new Error(
            result.message || "The email service did not confirm submission."
        );
    }
}
// SHARED FORM FUNCTION 
function setupForm(config) {
    const form = config.form;
    const submitBtn = form.querySelector("#submitBtn");
    const formStatus = form.querySelector("#formStatus");

    if (!submitBtn || !formStatus) {
        console.error("Submit button or status message is missing.");
        return;
    }

    const originalBtnText = submitBtn.textContent.trim();
    form.addEventListener("submit", async function (event) {
        event.preventDefault();

        // Get customer information
        const data = config.getData();

        // Clear previous status
        formStatus.textContent = "";
        formStatus.style.color = "red";

        // Check empty fields
        if (
            !data.name ||
            !data.email ||
            !data.phone ||
            !data.message
        ) {
            formStatus.textContent =
                "Please complete all required fields.";
            return;
        }

        if (!isValidName(data.name)) {

            formStatus.textContent =
                "Please enter a valid full name.";

            return;
        }

        if (!isValidEmail(data.email)) {

            formStatus.textContent =
                "Please enter a valid email.";

            return;
        }

const phoneInput = form.querySelector("#phone");

if (!isValidPhone(data.phone)) {

    formStatus.style.color = "red";

    formStatus.textContent =
        "Please enter a valid South African phone number.";

    alert("Please enter a valid South African phone number.");

    phoneInput.focus();

    return;
}

        if (data.message.length < 10) {

            formStatus.textContent =
                "Your message must contain at least 10 characters.";

            return;
        }

        const error = config.validate(data);

        if (error) {
            formStatus.textContent = error;
            return;
        }
        // Prevent multiple submissions
        submitBtn.disabled = true;
        submitBtn.textContent = "Sending...";

        formStatus.style.color = "blue";
        formStatus.textContent =
            "Submitting, please wait...";

        try {

            // Send information to FormSubmit
            await sendToAdmin({
                ...data,
                _subject: config.subject
            });

            // Successful submission
            formStatus.style.color = "green";

            formStatus.textContent =
                "Hi " + data.name +
                "! Your submission was successful. " +
                "Thank you for contacting 360 BOYZ SECURE. " +
                "We will get back to you soon.";

            alert(config.successAlert);

            // Clear form
            form.reset();

        } catch (error) {

            console.error("Form submission error:", error);

            formStatus.style.color = "red";

            formStatus.textContent =
                "Sorry, we could not confirm your submission. Please try again.";

            alert(
                "Your submission was not confirmed. Please check your connection or try again later."
            );

        } finally {

            // Restore button
            submitBtn.disabled = false;
            submitBtn.textContent = originalBtnText;
        }

    });
}
//CONTACT US PAGE
const contactForm = document.getElementById("contactForm");
      if (contactForm) {
            setupForm({
               form: contactForm,
        subject: "New Contact Form Message - 360 BOYZ SECURE",
        successAlert: "Your message has been sent successfully!",
        getData: function () {
            return {
                name: contactForm.querySelector("#name").value.trim(),
                email: contactForm.querySelector("#email").value.trim(),
                phone: contactForm.querySelector("#phone").value.trim(),
                message: contactForm.querySelector("#message").value.trim()
            };

        },
        validate: function (data) {
            return "";
        }
    });
}
// ENQUIRY PAGE
const enquiryForm = document.getElementById("enquiryForm");
if (enquiryForm) {
    setupForm({
        form: enquiryForm,
        subject: "New Enquiry - 360 BOYZ SECURE",
        successAlert: "Your enquiry has been sent successfully!",
        getData: function () {
            const select = enquiryForm.querySelector("#service");
            return {
                name: enquiryForm.querySelector("#name").value.trim(),
                email: enquiryForm.querySelector("#email").value.trim(),
                phone: enquiryForm.querySelector("#phone").value.trim(),
                service: select.value
                    ? select.options[select.selectedIndex].text.trim()  : "",
                location: enquiryForm.querySelector("#location").value.trim(),
                message: enquiryForm.querySelector("#message").value.trim()
            };
        },

        validate: function (data) {
            if (!data.service) {
                return "Please select the service you require.";
            }
            if (data.location.length < 3) {
                return "Please enter your location.";
            }
            return "";
        }
    });
}

//DATE AND TIME FUNCTION
function updateDateTime() {
    const now = new Date();
    const options = {
        weekday: "long",
        year: "numeric",
        month: "long",
        day: "numeric",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit"
    };
    const datetimeElement = document.getElementById("datetime");
    if (datetimeElement) {

        datetimeElement.textContent =
            now.toLocaleString("en-ZA", options);

    }

}

// Display date and time immediately
updateDateTime();

// Update date and time every second
setInterval(updateDateTime, 1000);




/* =====================================
   360 BOYZ SECURE SLIDESHOW
===================================== */

let slideIndex = 0;

const slides = document.querySelectorAll(".slide");

function showSlide(index) {

    if (slides.length === 0) {
        return;
    }

    slides.forEach(function(slide) {
        slide.style.display = "none";
    });

    slideIndex = (index + slides.length) % slides.length;

    slides[slideIndex].style.display = "block";
}


// NEXT AND PREVIOUS BUTTONS

function changeSlide(direction) {

    showSlide(slideIndex + direction);

}
// AUTOMATIC SLIDESHOW
if (slides.length > 0) {
    showSlide(0);
    setInterval(function() {
        showSlide(slideIndex + 1);
    }, 3000);
}

  // LIGHTBOX
const galleryImages = document.querySelectorAll(".gallery img");
const lightbox = document.getElementById("lightbox");
const lightboxImage = document.getElementById("lightbox-image");
let currentImage = 0;

// OPEN LIGHTBOX
if (lightbox && lightboxImage) {

    galleryImages.forEach(function(image, index) {

        image.addEventListener("click", function() {

            currentImage = index;

            lightboxImage.src = image.src;

            lightbox.style.display = "flex";

            document.body.style.overflow = "hidden";
        });
    });
    // CLOSE LIGHTBOX
    function closeLightbox() {
        lightbox.style.display = "none";
        document.body.style.overflow = "auto";
    }
    // CHANGE LIGHTBOX IMAGE
    function lightboxChange(direction) {
        if (galleryImages.length === 0) {
            return;
        }
        currentImage =
            (currentImage + direction + galleryImages.length)  % galleryImages.length;
        lightboxImage.src = galleryImages[currentImage].src;
    }
    // CLICK OUTSIDE TO CLOSE
    lightbox.addEventListener("click", function(event) {
        if (event.target === lightbox) {
            closeLightbox();
        }

    });


    // KEYBOARD CONTROLS

    document.addEventListener("keydown", function(event) {

        if (lightbox.style.display === "flex") {

            if (event.key === "Escape") {
                closeLightbox();
            }

            if (event.key === "ArrowRight") {
                lightboxChange(1);
            }

            if (event.key === "ArrowLeft") {
                lightboxChange(-1);
            }

        }

    });

}
